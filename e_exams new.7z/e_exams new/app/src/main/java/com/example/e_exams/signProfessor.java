package com.example.e_exams;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class signProfessor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_professor);
    }
}