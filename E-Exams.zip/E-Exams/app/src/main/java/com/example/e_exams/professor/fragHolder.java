package com.example.e_exams.professor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.e_exams.R;

public class fragHolder extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frag_holder);
    }
}