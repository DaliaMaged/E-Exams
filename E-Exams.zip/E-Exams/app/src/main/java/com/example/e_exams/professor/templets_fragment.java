package com.example.e_exams.professor;

import android.content.ClipData;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.e_exams.professor.models.mcqS;
import com.example.e_exams.professor.models.trueAndfalses;
import com.example.e_exams.professor.adapter.questionTFAdapter;
import com.example.e_exams.professor.adapter.questionMCQAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.e_exams.R;
import com.example.e_exams.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;


public class templets_fragment extends Fragment {

Button createExam;
RecyclerView rvMCQ,rvTrueNFalse;
TextView textView,textView3;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View rootView = inflater.inflate(R.layout.fragment_templets_fragment, container, false);
        createExam =rootView.findViewById(R.id.createBtn);
        rvMCQ =rootView.findViewById(R.id.rv_mcq);
        rvTrueNFalse =rootView.findViewById(R.id.rv_trueNfalse);
        textView =rootView.findViewById(R.id.textView);
        textView3 =rootView.findViewById(R.id.textView3);
      List <trueAndfalses> items=new ArrayList<>();

        trueAndfalses tf1 = new trueAndfalses("eddd","edddd","eddd");

        RecyclerView recyclerViewTF=(RecyclerView) rootView.findViewById(R.id.rv_trueNfalse);

        questionTFAdapter questionTFAdapter=new questionTFAdapter();

        recyclerViewTF.setAdapter(questionTFAdapter);
        recyclerViewTF.setLayoutManager(new LinearLayoutManager(getActivity().getBaseContext()));
//        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getActivity().getBaseContext());

//        recyclerViewTF.setLayoutManager(layoutManager);
//        LinearLayoutManager llm = new LinearLayoutManager(getActivity().getBaseContext());
//        llm.setOrientation(LinearLayoutManager.VERTICAL);



        mcqS mcq1 = new mcqS("eddd","edddd","eddd","three","four");

        RecyclerView recyclerViewMcq=(RecyclerView) rootView.findViewById(R.id.rv_mcq);
        questionTFAdapter questionAdapterMcq=new questionTFAdapter();
        recyclerViewMcq.setAdapter(questionAdapterMcq);





    return rootView;

    }
}