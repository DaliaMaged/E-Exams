package com.example.e_exams;

import java.util.ArrayList;

public interface subjectSelectedListener {
    void onSubjectChanged(ArrayList<String >arrayList);
}
